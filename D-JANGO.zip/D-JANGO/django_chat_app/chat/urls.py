from django.urls import path
from .views import UserListView, MessageListView

urlpatterns = [
    path('users/', UserListView.as_view(), name='user-list'),
    path('messages/<int:receiver_id>/', MessageListView.as_view(), name='message-list'),
]
